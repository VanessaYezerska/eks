public class One {
    int a;
    int b;
    int c;

    public One(int a, int b, int c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public void method1() {
        System.out.println("Це метод: " + a);
    }

    public void method2() {
        System.out.println("Це метод: " + b);
    }
     double methodArifm(){
        return (a + b + c)/3;
}


}
